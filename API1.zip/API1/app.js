const express = require("express");
const path = require("path");
const app = express();
const port = 3000;

// Configurar middleware para parsear solicitudes JSON y URL-encoded
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// www.sitio.com/  landpage
// Crear una ruta para servir el archivo index.html
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));
});

// www.sitio.com/api/usuario
// Ruta para manejar la solicitud del formulario usuario
app.post("/api/usuario", (req, res) => {
    const { nombre,email,password } = req.body;
    // Enviar respuesta al cliente
    res.send(`
        <html>
            <head>
                <title>My Session</title>
            </head>
            <body>
                <div class="container">
                    <h1>Welcome ${nombre} !!</h1>
                    <p>Your sign up info</p>
                    <p>Email: ${email}</p>
                    <p>Password: ${password}</p>
                </div>
            </body>
        </html>
    `);
});

app.listen(port, () => {
    console.log(`Servidor está escuchando en el puerto http://localhost:${port}`);
});
